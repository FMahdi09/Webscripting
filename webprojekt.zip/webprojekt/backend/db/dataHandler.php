<?php
include_once("models/appointment.php");
include_once("models/date.php");
include_once("models/comment.php");

class DataHandler
{
    private $db_obj;

    function __construct($db_obj)
    {
        $this->db_obj = $db_obj;
    }

    public function queryAllAppointments()
    {
        $data = $this->getAllAppointments();

        return $data;
    }

    public function queryAppointmentsByID($id)
    {
        $data = $this->getAppointmentsByID($id);

        return $data;
    }

    public function insertEntry($data)
    {
        $this->insertEntryDB($data);

        return true;
    }

    public function insertAppointment($data)
    {
        $this->insertAppointmentDB($data);

        return true;
    }

    private function getAllAppointments()
    {
        //creates an empty array
        $data = [];
        
        $sql_allAppointments = "SELECT * 
                                FROM appointments";
        //queries from all appointments from the database 
        $result_allAppointments = mysqli_query($this->db_obj, $sql_allAppointments);
        // fills $data with appointments until there are no more appointments to fetch, then returns $data
        while ($allAppointments = $result_allAppointments->fetch_assoc()) 
        {
            $newAppoitnment = new Appointment($allAppointments["id"], $allAppointments["title"],
                                              $allAppointments["description"],$allAppointments["date"]);
            $data[] = $newAppoitnment;
        }

        return $data;
    }

    private function getAppointmentsByID($id)
    {
        $data = [];

        //get appointment details
        $sql_getAppointment = "SELECT *
                               FROM appointments
                               WHERE id = '$id'";

        $result_getAppointment = mysqli_query($this->db_obj, $sql_getAppointment);

        $appointment = mysqli_fetch_assoc($result_getAppointment);

        $data[] = new Appointment($appointment["id"], $appointment["title"], $appointment["description"], $appointment["date"]);

        //get possible dates
        $sql_getAppointmentDates = "SELECT *
                                    FROM dates
                                    WHERE appointment_id = '$id'";

        $result_getAppointmentDates = mysqli_query($this->db_obj, $sql_getAppointmentDates);

        while($allAppointmentsDates = $result_getAppointmentDates->fetch_assoc())
        {
            $newAppoitnmentDate = new Date($allAppointmentsDates["id"], $allAppointmentsDates["date"], $allAppointmentsDates["time_begin"], $allAppointmentsDates["time_end"]);

            $data[] = $newAppoitnmentDate;
        }

        //get user comments
        $sql_getAppointmentComments = "SELECT *
                                       FROM entries
                                       WHERE appointment_id = '$id'";
        
        $result_getAppointmentComments = mysqli_query($this->db_obj, $sql_getAppointmentComments);

        while($appointmentComments = $result_getAppointmentComments->fetch_assoc())
        {
            $newAppoitnmentComment = new Comment($appointmentComments["name"], $appointmentComments["comment"]);

            $data[] = $newAppoitnmentComment;
        }

        return $data;
    }

    private function insertEntryDB($data)
    {
        //get appointment-id
        $sql_getID = "SELECT appointment_id
                      FROM dates
                      WHERE id = '$data->date_id'";

        $result_getID = mysqli_query($this->db_obj, $sql_getID);

        $appointment_id = $result_getID->fetch_assoc();

        //insert given data + appointment-id into db
        $sql_insertEntry = "INSERT INTO entries (appointment_id, date_id, name, comment)
                            VALUES (?,?,?,?)";

        $stmt_insertEntry = $this->db_obj->prepare($sql_insertEntry);

        $stmt_insertEntry->bind_param("iiss", $appointment_id["appointment_id"], $data->date_id, $data->name, $data->comment);

        $stmt_insertEntry->execute();
    }

    private function insertAppointmentDB($data)
    {
        //insert given data into db
        $sql_insertAppointment = "INSERT INTO appointments (title, description, date) VALUES (?,?,?)";

        $stmt_insertAppointment = $this->db_obj->prepare($sql_insertAppointment);

        $stmt_insertAppointment->bind_param("sss", $data->title, $data->description, $data->date);

        $stmt_insertAppointment->execute();
    }
}